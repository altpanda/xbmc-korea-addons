#!/bin/bash
zip -ru test src
